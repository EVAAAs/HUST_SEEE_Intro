#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"
#include "parements.h"

void Key(void);
int balance(float angle);
int Origin_balance(float angle);
void Set_Pwm(int moto);
void Xianfu_Pwm(void);
void key(void);
void Auto_Run(void);
int Position(int Encoder);
int Pre_Position(int Encoder);
int abs(int a);
void Move(long encoder,long target);
int Sway_Position_PID (int Encoder,int Target);
int Incremental_PI (int Encoder,int Target);
int Mean_Filter(int sensor);
void Find_Zero(void);
void Auto_run(void);
void Get_D_Angle_Balance(void);
u8 Turn_Off(void);
#define PI 3.14159265


#endif
