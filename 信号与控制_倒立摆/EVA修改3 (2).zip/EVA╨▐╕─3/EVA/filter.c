#include "filter.h"
/**************************************************************************
�������ܣ�ƽ�� �˲�
��ڲ������ٶ�
����  ֵ���˲��������
**************************************************************************/
int Mean_Filter(int sensor)
{
  u8 i;
  s32 Sum_Speed = 0;     
	s16 Filter_Speed;   
  static  s16 Speed_Buf[FILTERING_TIMES]={0};
  for(i = 1 ; i<FILTERING_TIMES; i++)
  {
    Speed_Buf[i - 1] = Speed_Buf[i];
  }
  Speed_Buf[FILTERING_TIMES - 1] =sensor;

  for(i = 0 ; i < FILTERING_TIMES; i++)
  {
    Sum_Speed += Speed_Buf[i];
  }
  Filter_Speed = (s16)(Sum_Speed / FILTERING_TIMES);//
	return Filter_Speed;
}

float IRR_filtering(IRR_Filtering *IRRF,float now_value){
	IRRF->now_value=IRRF->last_value*(1.0-IRRF->a_irr)+now_value*IRRF->a_irr;
	IRRF->last_value=IRRF->now_value;
	return IRRF->now_value;
}
void init_irr_filtering(IRR_Filtering *IRRF,float start_value,float irr){
	IRRF->a_irr=irr;
	IRRF->last_value=start_value;
	IRRF->now_value=start_value;
}
/*�������˲�����*/

static double KalmanFilter(const double ResrcData,double ProcessNiose_Q,double MeasureNoise_R)
{

    double R = MeasureNoise_R;
    double Q = ProcessNiose_Q;

    static double x_last;
    double x_mid;// = x_last
    double x_now;

    static double p_last;
    double p_mid ;
    double p_now;

    double kg;

    x_mid=x_last;                       //x_last=x(k-1|k-1),x_mid=x(k|k-1)
    p_mid=p_last+Q;                     //p_mid=p(k|k-1),p_last=p(k-1|k-1),Q=����

    /*
     *  �������˲��������ʽ
     */
	
    kg=p_mid/(p_mid+R);                 //kgΪkalman filter,R Ϊ����
    x_now=x_mid+kg*(ResrcData-x_mid);   //���Ƴ�����ֵ
    p_now=(1-kg)*p_mid;                 //����ֵ��Ӧ��covariance
    p_last = p_now;                     //����covariance ֵ
    x_last = x_now;                     //����ϵͳ״ֵ̬

    return x_now;

}
