/*
 * pid.c
 *
 *  Created on: Jul 7, 2021
 *      Author: 10161
 */


#include "pid.h"




void PID_init(pid_p *pid,float ref,float actual,float kp,float ki, float kd)
{
    //printf("PID_init begin \n");
    pid->REF= ref;		  	// ????????
    pid->ACTUAL= actual;			// adc?????
    pid->err= 0.0;				    // ???????????
    pid->err_last=0.0;			    // ??????
    pid->integral= 0.0;			  	// ???
    pid->Kp= kp;				    // ????
    pid->Ki= ki;				    // ????
    pid->Kd= kd;				    // ????
    pid->result=0;
    //printf("PID_init end \n");
}

float PID_realize(pid_p *pid, float vref, float v_now)
{

    pid->REF = vref;			// ???????
    pid->ACTUAL = v_now;	// ?????? = ADC_Value * 3.3f/ 4096
    pid->err =   pid->REF - pid->ACTUAL;	//????
    pid->result = pid->Kp * pid->err + pid->Ki * pid->integral + pid->Kd * ( pid->err - pid->err_last);
    pid->integral += pid->err;
    pid->err_last = pid->err;				//???????
    return pid->result;
}
