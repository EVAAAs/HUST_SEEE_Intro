/*
 * pid.h
 *
 *  Created on: Jul 7, 2021
 *      Author: 10161
 */

#ifndef INC_PID_H_
#define INC_PID_H_


typedef struct
{
    float REF;	  	//?????
    float ACTUAL;	//?????
    float err;			    //?????
    float err_last;		  	//????????
    float Kp,Ki,Kd;		  	//????????????
    float result;		    //pid????
    float integral;		  	//?????
}pid_p;



void PID_init(pid_p *pid,float ref,float actual,float kp,float ki, float kd);
float PID_realize(pid_p *pid, float vref, float v_now);




#endif /* INC_PID_H_ */
