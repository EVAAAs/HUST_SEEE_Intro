#ifndef __FILTER_H
#define __FILTER_H
#include "sys.h"
#include "parements.h"
int Mean_Filter(int sensor);//ƽ�� �˲�
typedef struct{

	float last_value;
	float now_value;
	float a_irr;

}IRR_Filtering;
float IRR_filtering(IRR_Filtering *IRRF,float now_value);
void init_irr_filtering(IRR_Filtering *IRRF,float start_value,float irr);
#endif
