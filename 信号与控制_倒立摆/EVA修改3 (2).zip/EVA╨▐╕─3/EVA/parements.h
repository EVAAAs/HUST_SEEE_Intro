/*
 * pid.h
 *
 *  Created on: Jul 7, 2021
 *      Author: 10161
 */

#ifndef __PAREMENTS_H_
#define __PAREMENTS_H_

#define Par_Position_A (200000)
#define Par_Position_B (200000)
#define Par_Position_Zero (200000)
#define Par_position_Bia_irr_filter_weight (0.2)

#define Par_balance_KP (80)
#define Par_balance_KD (30)
#define Par_position_KP (0.030)
#define Par_position_KD (5.13)
#define Par_pre_position_pid_KP (0.3)
#define Par_pre_position_pid_KD (5.7)
#define Par_sway_position_pid_KP (0.692)
#define Par_sway_position_pid_KD (20)
#define Par_incremental_pid_KP (2)
#define Par_incremental_pid_KI (2)
#define Par_Basics_Position_KD (200)


#define ANGLE_MIDDLE 3141
#define ANGLE_ORIGIN 1009

#define FILTERING_TIMES  4
#define POSITION_MIDDLE 220000
#define Par_Position_auto_stop 20000//Par_Position_auto_stop_motor_away_from_position_middle
#define POSITION_LEFT (POSITION_MIDDLE-Par_Position_auto_stop)
#define POSITION_RIGHT (POSITION_MIDDLE+Par_Position_auto_stop)

#define Par_Angle_middle_near (300) //Par_Angle_middle_near_make motor stop find 
#define Par_Position_left 70//the_side_left_away_from_the_motor

#define KALMAN_Q 0.02
#define KALMAN_R 7.0000

#define Par_Time_Delay_50_ms_num (10) //5ms each
#define Par_Position_control_period_num (4) //Tim3 5ms each and angle each


#define Par_slow_down_motor_all_step (5000)
#define Par_slow_down_motor_each_step (20)

#define Par_find_zero_ratio (0.1)
#define Par_find_zero_judge_count (200)
#define Par_find_zero_max_motor_velocity (2500)

#define Par_auto_sway_angle_volecity_detect_stop (30)
#define Par_auto_sway_target_Position_ratio (0.6)//0.6
#define Par_auto_sway_target_Position (Par_auto_sway_target_Position_ratio*Par_Position_auto_stop)
#define Par_auto_sway_angle_origin_and_middle_near (200) //Par_Angle_origin_near_make motor can sway next time 
#define Par_from_auto_sway_to_balance_ratio_right (0.25)
#define Par_from_auto_sway_to_balance_ratio_left (0.9)
#define Par_from_auto_sway_to_balance_judge_num (5)
#define Par_auto_sway_max_moto_volecity (4200)//4200
#define Par_balance_position_control_delay (30)//30*5ms
#define Par_balance_position_shift_delay (500)//500*5ms
#define Par_balance_position_shift_step (10)
#define Par_balance_angle_KD_delay (200)//500*5ms


#endif /* INC_PID_H_ */
